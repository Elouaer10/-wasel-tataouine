create table if not exists public.couriers (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 phone text not null,
 vehicle text not null,
 area text,
 status text not null default 'pending',
 created_at timestamptz not null default now()
);

create table if not exists public.orders (
 id uuid primary key default gen_random_uuid(),
 customer_name text not null,
 customer_phone text not null,
 pickup text not null,
 dropoff text not null,
 order_type text not null,
 details text,
 delivery_fee numeric(8,2) not null default 5,
 status text not null default 'open',
 courier_id uuid references public.couriers(id),
 created_at timestamptz not null default now(),
 accepted_at timestamptz,
 completed_at timestamptz
);

alter table public.couriers enable row level security;
alter table public.orders enable row level security;

create policy "public can create courier application"
on public.couriers for insert to anon with check (true);

create policy "public can create orders"
on public.orders for insert to anon with check (true);

create policy "public can read approved couriers"
on public.couriers for select to anon using (status='approved');

create policy "public can read open orders"
on public.orders for select to anon using (status='open');

create policy "public can accept open orders"
on public.orders for update to anon
using (status='open')
with check (status='accepted');
