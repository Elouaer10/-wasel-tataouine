# Wasel Tataouine — Production Starter

هذا المشروع هو نسخة جاهزة للتوصيل بباك-إند حقيقي. الواجهة تعمل مباشرة، وتستعمل Supabase عند وضع بيانات المشروع في `config.js`.

## التشغيل
1. انسخ `config.example.js` إلى `config.js`.
2. ضع `SUPABASE_URL` و `SUPABASE_ANON_KEY`.
3. أنشئ الجداول باستعمال `supabase_schema.sql`.
4. ارفع الملفات إلى Vercel/Netlify/Cloudflare Pages أو أي استضافة static.

## ملاحظات
- لا تضع Service Role Key في الواجهة.
- النسخة الحالية لا تنفذ دفعًا إلكترونيًا.
- لا تُرسل بيانات حساسة في الطلبات.
- قبل التشغيل التجاري: راجع حماية المعطيات، شروط الخدمة، المسؤولية والتأمين والصيغة القانونية.
