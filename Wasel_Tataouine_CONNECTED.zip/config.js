window.WASEL_CONFIG = {
  SUPABASE_URL: "https://nrtyfxrhhecvmjohsxto.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_GpCMM3u7UXEnEbOB_mTYkg_Q3Kacmec"
};
